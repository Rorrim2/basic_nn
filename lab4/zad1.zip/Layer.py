import numpy as np

class Layer:
    def __init__(self, array):
        self.layer_weights = np.array(array)